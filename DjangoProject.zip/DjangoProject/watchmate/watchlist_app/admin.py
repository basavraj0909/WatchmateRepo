from django.contrib import admin
from .models import Watchlist, StreamPlatform, Reviews

# admin.site.register(Movie)
admin.site.register(Watchlist)
admin.site.register(StreamPlatform)
admin.site.register(Reviews)
# Register your models here.
