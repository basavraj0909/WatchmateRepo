from django.urls import path, include

# from watchmate import watchlist_app
from rest_framework.routers import DefaultRouter

"""CLASS BASED VIEW"""
from .views import (WatchDetailView, WatchlistView, StreamPlatVS,
                    Reviewlist, ReviewDetail, ReviewCreate, UserReview)

router = DefaultRouter()
router.register('stream', StreamPlatVS, basename='streamplatform')


urlpatterns = [
    path('list/', WatchlistView.as_view(), name='movie-list'),
    path('<int:pk>/', WatchDetailView.as_view(), name='movie-detail'),

    path('', include(router.urls)),

    # path('stream/', StreamPlat.as_view({'get':'list'}), name='stream'),
    # path('stream/<int:pk>', StremDetailView.as_view(), name='stream-detail'),

    path('<int:pk>/reviews/', Reviewlist.as_view(), name='stream-detail'),
    path('<int:pk>/review-create/', ReviewCreate.as_view(), name='review-create'),
    path('review/<int:pk>/', ReviewDetail.as_view(), name='review-detail'),

    # path('review/', Reviewlist.as_view(), name='review-list'),
    # path('review/<int:pk>', ReviewDetail.as_view(), name='review-detail'),

    path('reviews/<str:username>', UserReview.as_view(), name='review-detail'),
]

"""FUNCTION BASED VIEW"""
# from .views import movie_list, movie_detail
# urlpatterns = [
    # path('list/', movie_list, name='movie-list'),
    # path('<int:pk>', movie_detail, name='movie-detail'),
# ]
