from django.shortcuts import get_object_or_404
from rest_framework import mixins, generics
from rest_framework.decorators import api_view
from rest_framework.exceptions import ValidationError
from rest_framework.permissions import IsAuthenticated, IsAuthenticatedOrReadOnly
from rest_framework.response import Response
from rest_framework.status import HTTP_204_NO_CONTENT, HTTP_400_BAD_REQUEST, HTTP_404_NOT_FOUND


from .permissions import IsAdminOrReadOnly, ReviewUserOrReadOnly
from watchmate.watchlist_app.models import Watchlist, StreamPlatform, Reviews
from watchmate.watchlist_app.api.serializers import (WatchListSerializer,
                                                     StreamPlatVS            StreamPlatformSerializer,
                                            ReviewSerializer)
"""CLASS BASED VIEW"""
from rest_framework.views import APIView
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from rest_framework import viewsets


class UserReview(generics.ListAPIView):

    serializer_class = ReviewSerializer
    # permission_classes = [IsAuthenticated]

    def get_queryset(self):
        username = self.kwargs['username']
        return Reviews.objects.filter(review_user__username=username) # used __username because it is foregn key


class ReviewCreate(generics.CreateAPIView):
    serializer_class = ReviewSerializer
    queryset = Reviews.objects.all()
    permission_classes = [IsAuthenticated]


    def perform_create(self,serializer):

        pk = self.kwargs.get('pk')
        watchlist = Watchlist.objects.get(pk=pk)

        review_user = self.request.user
        review_qset = Reviews.objects.filter(watchlist=watchlist,
                                             review_user=review_user)

        if review_qset.exists():
            raise ValidationError("Yoou have already added reviews to this movie")

        if watchlist.number_ratings ==0:
            watchlist.avg_rating = serializer.validated_data['rating']
        else:
            watchlist.avg_rating = (watchlist.avg_rating + serializer.validated_data['rating'])/2

        watchlist.number_ratings += 1
        watchlist.save()
        serializer.save(watchlist=watchlist, review_user=review_user)


class Reviewlist(generics.ListAPIView):
    queryset = Reviews.objects.all()
    serializer_class = ReviewSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        pk = self.kwargs['pk']
        return Reviews.objects.filter(watchlist=pk)


class ReviewDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Reviews.objects.all()
    serializer_class = ReviewSerializer
    permission_classes = [ReviewUserOrReadOnly]
    # permission_classes = [AdminOrReadOnly]

# class ReviewDetail(mixins.RetrieveModelMixin, generics.GenericAPIView):
#     queryset = Reviews.objects.all()
#     serializer_class = ReviewSerializer
#
#     def get(self, request, *args, **kwargs):
#         return self.retrieve(request, *args, **kwargs)

# CLASS BASED VIEWs: generic views alonf with mixins
# class Reviewlist(mixins.ListModelMixin,
#                  mixins.CreateModelMixin,
#                  generics.GenericAPIView):
#     queryset = Reviews.objects.all()
#     serializer_class = ReviewSerializer
#
#     def get(self, request,*args,**kwargs):
#         return self.list(request,*args,**kwargs)
#
#     def post(self, request,*args,**kwargs):
#         return self.create( request,*args,**kwargs)

    class StreamPlatVS(viewsets.ViewSet):
    permission_classes = [IsAdminOrReadOnly]

    def list(self,request):
        queryset = StreamPlatform.objects.all()
        serializer = StreamPlatformSerializer(queryset, many=True)
        return Response(serializer.data)

    def retrieve(self, request, pk=None ):
        queryset = StreamPlatform.objects.all()
        stream = get_object_or_404(queryset, pk=pk)
        serializer = StreamPlatformSerializer(stream)
        return Response(serializer.data)

    def create(self, request):
        serializer = StreamPlatformSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        else:
            return Response(serializer.errors)


    def destroy(self,request,pk):
        pk = self.kwargs.get('pk')
        platform = StreamPlatform.objects.get(pk=pk)
        platform.delete()
        return Response(status=HTTP_204_NO_CONTENT)

# class StreamPlatVS(viewsets.ReadOnlyModelViewSet ):
# class StreamPlatVS(viewsets.ModelViewSet):
#     queryset = StreamPlatform.objects.all()
#     serializer_class = StreamPlatformSerializer


# class StreamPlatView(APIView):
#
#     def get(self, request):
#         platforms = StreamPlatform.objects.all()
#         serializer = StreamPlatformSerializer(platforms,many=True)
#
#         return Response(serializer.data)
#
#     def post(self,request):
#         serializer = StreamPlatformSerializer(data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             return Response(serializer.data)
#         else:
#             return Response(serializer.errors)

# class StremDetailView(APIView):
#
#     def get(self,request,pk):
#         try:
#             platform = StreamPlatform.objects.get(pk=pk)
#         except StreamPlatform.DoesNotExist:
#             return Response({'error':'platform not found'},status=HTTP_404_NOT_FOUND)
#         serializer = StreamPlatformSerializer(platform)
#
#         return Response(serializer.data)
#
#     def put(self,request,pk):
#         platform = StreamPlatform.objects.get(pk=pk)
#         serializer = StreamPlatformSerializer(platform,data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             return Response(serializer.data)
#         else:
#             return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)


    # def delete(self, request,pk):
    #     platform = StreamPlatform.objects.get(pk=pk)
    #     platform.delete()
    #     return Response(status=HTTP_204_NO_CONTENT)


class WatchlistView(APIView):
    permission_classes = [IsAdminOrReadOnly]

    def get(self, request):
        movies = Watchlist.objects.all()
        serializer = WatchListSerializer(movies,many=True)

        return Response(serializer.data)

    def post(self,request):
        serializer = WatchListSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        else:
            return Response(serializer.errors)

class WatchDetailView(APIView):
    permission_classes = [IsAdminOrReadOnly]

    def get(self,request,pk):
        try:
            movie = Watchlist.objects.get(pk=pk)
        except Watchlist.DoesNotExist:
            return Response({'error':'watchlist not found'},status=HTTP_404_NOT_FOUND)
        serializer = WatchListSerializer(movie)

        return Response(serializer.data)

    def put(self,request,pk):
        movie = Watchlist.objects.get(pk=pk)
        serializer = WatchListSerializer(movie,data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        else:
            return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)


    def delete(self, request,pk):
        movie = Watchlist.objects.get(pk=pk)
        movie.delete()
        return Response(status=HTTP_204_NO_CONTENT)


"""FUNCTION BASED VIEW"""

# @api_view(['GET','POST'])
# def movie_list(request):
#     if request.method == 'GET':
#         movies = Movie.objects.all()
#         serializer = MovieSerializer(movies, many=True)
#         return Response(serializer.data)
#
#     if request.method == 'POST':
#         serializer = MovieSerializer(data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             return Response(serializer.data)
#         else:
#             return Response(serializer.errors )
#
#
# @api_view(['GET','PUT','DELETE'])
# def movie_detail(request,pk):
#     if request.method == 'GET':
#         try:
#             movie = Movie.objects.get(pk=pk)
#         except Movie.DoesNotExist:
#             return Response({'error':'movie not found'},status=HTTP_404_NOT_FOUND)
#         serializer = MovieSerializer(movie)
#
#         return Response(serializer.data)
#
#     if request.method == 'PUT':
#         movie = Movie.objects.get(pk=pk)
#         print(movie)
#         serializer = MovieSerializer(movie,data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             return Response(serializer.data)
#         else:
#             return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)
#
#     if request.method == 'DELETE':
#         movie = Movie.objects.get(pk=pk)
#         movie.delete()
#
#         return Response(status=HTTP_204_NO_CONTENT)