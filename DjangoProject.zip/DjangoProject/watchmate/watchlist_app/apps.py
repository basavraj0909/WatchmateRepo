from django.apps import AppConfig


class WatchlistAppConfig(AppConfig):
    name = 'watchlist_app'
